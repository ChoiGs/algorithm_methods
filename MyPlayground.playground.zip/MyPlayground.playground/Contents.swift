import Foundation
import UIKit

func solution(_ clothes:[[String]]) -> Int {
    var dic = [String : Int]()
    clothes.forEach { (data) in
        guard let type = data.last else {return}
        guard let key = data.first else {return}
        if(!dic.keys.contains(key)) {
            if(dic["\(type)"] == nil) {
                dic["\(type)"] = 1
            }else {
                dic["\(type)"]! += 1
            }
        }
    }
    
    print(dic.values)
    var data_c : Int = 1
    dic.values.forEach { (d_cnt) in
        data_c = data_c * (d_cnt + 1)
    }
    return data_c - 1
}

solution([["yellow_hat", "headgear"], ["blue_sunglasses", "eyewear"], ["green_turban", "headgear"]])
